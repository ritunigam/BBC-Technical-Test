/**
 * Project BBC Voting Technical Challenge
 * @author Ritu Nigam
 * voteServlet.java to respond to user voting and calling CountMeUP
 */
package BBCVoting;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


@WebServlet("/voteServlet")
public class voteServlet extends HttpServlet {
    
    voteCount vc = new voteCount(); 
    
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
 
        // read form fields
        String username = request.getParameter("username");
        String candidate1 = request.getParameter("CandidateVote1");
        String candidate2 = request.getParameter("CandidateVote2");
        String candidate3 = request.getParameter("CandidateVote3");
         
        System.out.println("username: " + username);
        System.out.println("Candidate1: " + candidate1);
        System.out.println("Candidate2: " + candidate2);
        System.out.println("Candidate3: " + candidate3);
        
        String msg = "Added your Votes";
        int addReturn=0; 
        int countV =0;
        if(!candidate1.equalsIgnoreCase("c0"))
            countV++;
        if(!candidate2.equalsIgnoreCase("c0"))
            countV++;
        if(!candidate3.equalsIgnoreCase("c0"))
            countV++;
        if(countV <=3){
            addReturn= vc.addUser(username, countV);
        }
        else
            msg="You have voted more than thrice";
        // Call result count voting
        vc.CountMeUP();

        PrintWriter out=response.getWriter();
         if (addReturn>=3){
           
            msg="You have voted more than thrice" + addReturn;
            out.print(msg);
            request.getRequestDispatcher("/vote.html").include(request, response);            
         }
        else{
            msg+=" : " +addReturn;
            out.print(msg);
            response.sendRedirect("/BBCVoting/index.htm");
        }
        out.flush();
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
         vc.CountMeUP();
        response.sendRedirect("/BBCVoting/index.htm");
    }

}
