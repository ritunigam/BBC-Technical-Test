
package BBCVoting;

import java.util.Hashtable;

/**
 * Project BBC Voting Technical Challenge
 * @author Ritu Nigam
 */
public class voteCount {

    static int maxvote=3;    
    Hashtable<String, Integer> userVote = new Hashtable<String, Integer>();

    /*
    * Constuructor initializes 
    */
    public voteCount(){
        userVote.put("u1",0);        
    }
    /*
    * AddUser will add the name of user check is already voted and check max vote reached
    * Assuming not storing choice of candidate
    * parameter user name
    * parameter number of votes
    */
    public int addUser(String user, int numVote){
        int num=numVote;
        VoteResultSingleton vr = VoteResultSingleton.getInstance();
        vr.totalVotes +=numVote;
        if(userVote.containsKey(user)){
           num= userVote.get(user);           
        }
        else{
            if (numVote<=maxvote){
                userVote.put(user, numVote);
                vr.totalVotes +=numVote;
            }            
            else
                num=4; // assume reached max limit
        }
        System.out.println("In addUser num="+ num);
        return num;
    }
  

    /*
    * CountMeUP will call Singleton class instance and then call voteCalculate method
    * Assuming Singleton hashtable will be populated with result
    * no parameter 
    */
    public void CountMeUP(){
//      
        VoteResultSingleton vr = VoteResultSingleton.getInstance();
        vr.voteCalculate();
        System.out.println("Now in CountMeUP");            
    }
    
    
}
