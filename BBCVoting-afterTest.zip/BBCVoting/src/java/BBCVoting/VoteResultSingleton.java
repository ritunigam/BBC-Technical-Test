/**
 * Project BBC Voting Technical Challenge
 * @author Ritu Nigam
 */
package BBCVoting;

import java.util.Hashtable;
/*
* Singleton class for Voting Result
* Assuming Singleton hashtable will be populated with result
*/
public class VoteResultSingleton {
   private static VoteResultSingleton instance = null;
   /* Fixed candidates percentage*/
   final static int[] percentCand = {5,10,20,25,40};
   /*total votes recived */
   public static int totalVotes;
   /* result of voting */
   public static Hashtable<String, Integer> voteCand = new Hashtable<String, Integer>();
   
   /* A private Constructor prevents any other
    * class from instantiating.
    */
   private VoteResultSingleton() {
      totalVotes=1000;
      System.out.println(" inInit of Singleton");
      voteCalculate();
   }
   /* Static 'instance' method */
   public static VoteResultSingleton getInstance() {
      if(instance == null) {
         instance = new VoteResultSingleton();
      }
      return instance;
   }
    /* voteCalculate methods will use Singleton hashtable and populated with result */
   protected static void voteCalculate( ) {
      /*Assume for testing increasing votes by 100 - for testing */
      if (totalVotes>=1000)
            totalVotes = totalVotes + 100;
      
        /*Calculate based on percentage and total votes casted and fill hashtable with results  */
        Integer c1 = (Integer)percentCand[0]*(totalVotes/100);
        Integer c2 = (Integer)percentCand[1]*(totalVotes/100);
        Integer c3 = (Integer)percentCand[2]*(totalVotes/100);
        Integer c4 = (Integer)percentCand[3]*(totalVotes/100);
        Integer c5 = (Integer)percentCand[4]*(totalVotes/100);
        voteCand.put("c1",c1);
        voteCand.put("c2",c2);
        voteCand.put("c3",c3);
        voteCand.put("c4",c4);
        voteCand.put("c5",c5);
       System.out.println("voteCalculate for singleton");
   }

}
